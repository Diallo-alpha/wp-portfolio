jQuery(document).ready(function( $ ) {

    $('#return-to-pantheon')
	    .detach()
	    .prependTo('#loginform')
	    .show();

});